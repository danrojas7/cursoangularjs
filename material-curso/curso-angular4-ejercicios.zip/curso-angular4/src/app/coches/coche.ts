export class Coche{
	constructor(
		public nombre:string,
		public caballaje:string,
		public color:string,
	){}
}